use salt;
CREATE TABLE IF NOT EXISTS attraction(
	id int auto_increment,
	name varchar(10) not null,
    info varchar(150) not null,
    tag char(4) not null,
    ride varchar(5),
    age varchar(10),
    tall varchar(15),
    filename varchar(20),
    primary key(id)    
)default charset=utf8;
select*from attraction;
SELECT * FROM attraction where tag= '키디존' and age='제한 없음' and tall='130cm~190cm';

drop table attraction;